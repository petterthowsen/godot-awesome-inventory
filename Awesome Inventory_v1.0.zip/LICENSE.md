# License

This software is free to use, modify and share but it must use this exact same license.
You can use it for commercial game projects.
